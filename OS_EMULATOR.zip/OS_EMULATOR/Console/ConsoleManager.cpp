#include <iostream>

#include "ConsoleManager.h"
#include "../Processor/Scheduler.h"

UI_Manager& ui = UI_Manager::getInstance();
ConsoleManager* ConsoleManager::sharedInstance = nullptr;

ConsoleManager* ConsoleManager::getInstance(){
    if (!sharedInstance)
        initialize();

    return sharedInstance;
}

void ConsoleManager::initialize(){
    if (!sharedInstance)
        sharedInstance = new ConsoleManager();
}

void ConsoleManager::destroy(){
    if (sharedInstance){
        delete sharedInstance;
        sharedInstance = nullptr;
    }
}


ConsoleManager::ConsoleManager(){
    running = true;

    consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);

    const std::shared_ptr<MainConsole> mainConsole = std::make_shared<MainConsole>();
    /*
    const std::shared_ptr<MarqueeConsole> marqueeConsole = std::make_shared<MarqueeConsole>();
    const std::shared_ptr<SchedulingConsole> schedulingConsole = std::make_shared<SchedulingConsole>();
    const std::shared_ptr<MemorySimulationConsole> memoryConsole = std::make_shared<MemorySimulationConsole>();
    */
    

    consoleTable[MAIN_CONSOLE] = mainConsole;
    /*
    consoleTable[MARQUEE_CONSOLE] = marqueeConsole;
    consoleTable[SCHEDULING_CONSOLE] = schedulingConsole;
    consoleTable[MEMORY_CONSOLE] = memoryConsole;
    */

    switchConsole(MAIN_CONSOLE);
}

void ConsoleManager::drawConsole() const{
    if (currConsole)
        currConsole->display();
    else
        std::cout << "Error: There is no assigned console." << std::endl;
}

void ConsoleManager::process() const{
    if (currConsole)
        currConsole->process();
    else
        std::cout << "Error: There is no assigned console." << std::endl;
}

void ConsoleManager::switchConsole(const std::string &consoleName) {
    auto it = consoleTable.find(consoleName);
    if (it != consoleTable.end()){
        ui.clear();
        prevConsole = currConsole;
        currConsole = it->second;
        currConsole->onEnabled();
    }
    else
        std::cout << "Error: Console Name '" << consoleName << "' Cannot Be Found." << std::endl;
}

void ConsoleManager::registerScreen(std::shared_ptr<BaseScreen> screenReference){
    auto it = consoleTable.find(screenReference->getName());
    if (it != consoleTable.end()){
        std::cout << "Error: Screen Name '" << screenReference->getName() << "' Already Exists. Use A Different Name." << std::endl;
    }
    else
        consoleTable[screenReference->getName()] = screenReference;
}

void ConsoleManager::unregisterScreen(const std::string &screenName){
    auto it = consoleTable.find(screenName);
    if (it != consoleTable.end())
        consoleTable.erase(screenName);
    else
        std::cout << "Error: Console Name '" << screenName << "' Cannot Be Found." << std::endl;
}

void ConsoleManager::listScreens() const {
    Scheduler& scheduler = Scheduler::getInstance(0);

    std::vector<std::shared_ptr<Process>> runningProcesses = scheduler.getRunningProcesses();
    std::vector<std::shared_ptr<Process>> finishedProcesses = scheduler.getFinishedProcesses();

    std::cout << "---------------------------" << std::endl;
    
    std::cout << "Running Processes:" << std::endl;
    for (const auto& process : runningProcesses)
        std::cout << "Name: " << process->getName() << " | Core: " << process->getCpuCoreID() << " |" << std::endl;

    std::cout << std::endl << std::endl;

    std::cout << "Finished Processes:" << std::endl;
    for (const auto& process : finishedProcesses) 
        std::cout << "Name: " << process->getName() << " | Core: " << process->getCpuCoreID() << " |" << std::endl;

    std::cout << "---------------------------" << std::endl;
}

void ConsoleManager::getPreviousConsole(){
    if (prevConsole){
        currConsole = prevConsole;
        prevConsole = nullptr;
    }
}

void ConsoleManager::exit(){
    running = false;
}

bool ConsoleManager::isRunning() const{
    return running;
}

HANDLE ConsoleManager::getConsoleHandle() const{
    return consoleHandle;
}