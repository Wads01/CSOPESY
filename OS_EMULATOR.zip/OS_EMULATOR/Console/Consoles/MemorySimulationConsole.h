#pragma once
#ifndef MEMORY_SIMULATION_CONSOLE_H
#define MEMORY_SIMULATION_CONSOLE_H

#include "../BaseScreen.h"

class MemorySimulationConsole : public BaseScreen{
public:

private:

};

#endif