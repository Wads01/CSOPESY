#include <iostream>
#include <random>
#include <chrono>

#include "MainConsole.h"
#include "../ConsoleManager.h"
#include "../../UI/UI_Manager.h"
#include "../../Processor/Scheduler.h"
#include "../../Processor/CommandProcessor.h"

MainConsole::MainConsole() : BaseScreen(nullptr, MAIN_CONSOLE) {}

void MainConsole::onEnabled(){
    UI_Manager& ui = UI_Manager::getInstance();
    ui.clear();
    ui.printMainHeader();
    ui.printMainWelcome();


    //HOMEWORK
    if (homeworkThread.joinable())
        homeworkThread.join();

    homeworkThread = std::thread(&MainConsole::June_11_Homework, this);
}

void MainConsole::display(){
    std::cout << "Main Console Display" << std::endl;
}

void MainConsole::process(){
    std::string command;
    std::cout << std::endl << "Enter a command:>";
    std::getline(std::cin, command);
    processCommand(command);
}

void MainConsole::processCommand(const std::string &command){
    UI_Manager& ui = UI_Manager::getInstance();
    ConsoleManager* consoleManager = ConsoleManager::getInstance();
    CommandProcessor& processor = CommandProcessor::getInstance();
    std::vector<std::string> tokens = processor.tokenize(command, ' ');

    if (tokens.empty())
        return;

    const std::string& command_0 = tokens[0];

    if (command_0 == "help")
    {
        UI_Manager& ui = UI_Manager::getInstance();
        ui.printMainCommandList();
    }
    else if (command_0 == "clear")
    {
        ui.clear();
        onEnabled();
    }
    else if (command_0 == "marquee")
    {
        //WIP
    }
    else if (command_0 == "nvidia_smi")
    {
        //WIP
    }
    else if (command_0 == "screen")
    {
        if(tokens.size() == 3)
        {
            if(tokens[1] == "-s")
            {
                // Generate PID
                int pid = ui.generatePID(ui.pid_generate);

                // Set requirement flags
                Process::RequirementFlags reqFlags = {true, 1, true, 512};

                //Get current timestamp
                std::string timestamp = ui.generateTimestamp();

                // Create Process
                std::shared_ptr<Process> newProcess = std::make_shared<Process>(pid, tokens[2], reqFlags, timestamp);

                // Create Screen with Process
                std::shared_ptr<BaseScreen> newScreen = std::make_shared<BaseScreen>(newProcess, tokens[2]);
                consoleManager->registerScreen(newScreen);
                std::cout << "Screen Name: '" << tokens[2] << "' successfully created." << std::endl;
            }
            else if(tokens[1] == "-r")
            {
                consoleManager->switchConsole(tokens[2]);
                ui.clear();
                onEnabled();

            }
            else if(tokens[1] == "-d")
            {
                consoleManager->unregisterScreen(tokens[2]);
                std::cout << "Screen Name: '" << tokens[2] << "' successfully removed." << std::endl;
            }
        }
        else if(tokens.size() == 2)
        {
            if(tokens[1] == "-ls")
            {
                consoleManager->listScreens();
            }
        }
    }
    else if (command_0 == "exit")
    {
        consoleManager->exit();
        std::cout << "Program Terminated." << std::endl;
    }
    else
    {
        std::cout << "Unrecognized command:>" << command << std::endl;
    }

    tokens.clear();
}

void MainConsole::June_11_Homework(){


}

MainConsole::~MainConsole(){
    if (homeworkThread.joinable()){
        homeworkThread.join();
    }
}