#pragma once
#ifndef MARQUEE_CONSOLE_H
#define MARQUEE_CONSOLE_H

#include "../BaseScreen.h"

class MarqueeConsole : public BaseScreen{
public:

private:

};

#endif