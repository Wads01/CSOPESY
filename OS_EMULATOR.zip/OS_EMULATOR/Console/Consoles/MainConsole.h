#pragma once
#ifndef MAIN_CONSOLE_H
#define MAIN_CONSOLE_H

#include <thread>

#include "../BaseScreen.h"
#include "../../Processor/Process.h"

class MainConsole : public BaseScreen{
public:
    MainConsole();
    ~MainConsole();
    void onEnabled() override;
    void display() override;
    void process() override;
    void processCommand(const std::string &command);
    

    void June_11_Homework();
    std::thread homeworkThread;
};

#endif