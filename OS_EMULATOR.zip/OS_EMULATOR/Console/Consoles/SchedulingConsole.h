#pragma once
#ifndef SCHEDULING_CONSOLE_H
#define SCHEDULING_CONSOLE_H

#include "../BaseScreen.h"

class SchedulingConsole : public BaseScreen{
public:

private:

};

#endif