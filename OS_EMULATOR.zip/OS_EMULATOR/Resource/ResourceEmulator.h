#pragma once
#ifndef RESOURCE_EMULATOR_H
#define RESOURCE_EMULATOR_H

class ResourceEmulator{
public:
    ResourceEmulator();
private:

};

#endif