#include "Scheduler.h"
#include <iostream>
#include <chrono>
#include <thread>

Scheduler* Scheduler::sharedInstance = nullptr;

Scheduler::Scheduler() :
      schedulerAlgorithm("NULL"), 
      quantumCycles(0), 
      batchProcessFrequency(0),
      minInstructions(0),
      maxInstructions(0),
      delaysPerExecution(0),
      numCores(0),
      running(true) {
    runningProcesses.resize(numCores, nullptr);
}

Scheduler::~Scheduler(){
    shutdown();
}

Scheduler& Scheduler::getInstance(){
    if (!sharedInstance)
        initialize();

    return *sharedInstance;
}

void Scheduler::getInfo(){
    std::cout << "Scheduler Parameters:" << std::endl;
    std::cout << "Number of CPU cores: " << numCores << std::endl;
    std::cout << "Scheduler algorithm: " << schedulerAlgorithm << std::endl;
    std::cout << "Quantum cycles: " << quantumCycles << std::endl;
    std::cout << "Batch process frequency: " << batchProcessFrequency << std::endl;
    std::cout << "Minimum instructions per process: " << minInstructions << std::endl;
    std::cout << "Maximum instructions per process: " << maxInstructions << std::endl;
    std::cout << "Delays per execution: " << delaysPerExecution << std::endl;

}

void Scheduler::initialize(){
    if (!sharedInstance)
        sharedInstance = new Scheduler();
}

void Scheduler::destroy(){
    if (sharedInstance){
        delete sharedInstance;
        sharedInstance = nullptr;
    }
}

void Scheduler::addProcess(std::shared_ptr<Process> process){
    std::unique_lock<std::mutex> lock(queueMutex);

    // Add the process to queue
    readyQueue.push(process);
    process->currentState = Process::WAITING;
    processCV.notify_one();
}


void Scheduler::run(){
    if (schedulerAlgorithm == "rr"){
        roundRobin(quantumCycles);
    }
    else{
        while (running){
            std::unique_lock<std::mutex> lock(queueMutex);

            // Wait for processes
            processCV.wait(lock, [this] { return !readyQueue.empty() || !running; });

            // Assign processes to available cores
            for (int i = 0; i < numCores; ++i) {
                if (!runningProcesses[i] && !readyQueue.empty()){
                    auto process = readyQueue.front();
                    readyQueue.pop();
                    runningProcesses[i] = process;
                    process->currentState = Process::RUNNING;
                    coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process, i));
                }
            }

            lock.unlock();
            std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<long long>(delaysPerExecution * 1000))); // Delays per Execution
        }
    }
}

void Scheduler::roundRobin(int quantumCycles){
    while (running){
        std::unique_lock<std::mutex> lock(queueMutex);

        // Wait for processes
        processCV.wait(lock, [this] { return !readyQueue.empty() || !running; });

        int count = 0;
        while (!readyQueue.empty() && count < numCores){
            auto process = readyQueue.front();
            readyQueue.pop();
            runningProcesses[count] = process;
            process->currentState = Process::RUNNING;

            // Set quantumCycles duration
            auto timer = std::chrono::steady_clock::now() + std::chrono::milliseconds(quantumCycles);
            while (process->currentState == Process::RUNNING && std::chrono::steady_clock::now() < timer){
                process->executeTask();
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }

            // If process still running
            if (process->currentState == Process::RUNNING){
                process->currentState = Process::WAITING;
                readyQueue.push(process);
            }
            else{
                process->currentState = Process::FINISHED;
                finishedProcesses.push_back(process);
            }

            // Go to the next core
            ++count;
        }

        lock.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(static_cast<long long>(delaysPerExecution * 1000))); // Delays Per Execution
    }
}


void Scheduler::executeProcess(std::shared_ptr<Process> process, int coreID){
    process->cpuCoreID = coreID;
    process->executeTask();

    {
        std::lock_guard<std::mutex> lock(process->mutex);
        process->currentState = Process::FINISHED;
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex);
        runningProcesses[coreID] = nullptr; // Free up core
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex);
        finishedProcesses.push_back(process);   // Put process to finished processes
    }
}

void Scheduler::readConfigFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Error opening config file: " + filename);
    }

    std::string line;
    while (std::getline(file, line)){
        std::istringstream iss(line);
        std::string key, value;
        if (iss >> key >> value){
            if (key == "num-cpu")
            {
                numCores = std::stoi(value);
                runningProcesses.resize(numCores, nullptr);
            }
            else if (key == "scheduler") { schedulerAlgorithm = value; }
            else if (key == "quantum-cycles") { quantumCycles = std::stoi(value); }
            else if (key == "batch-process-freq") { batchProcessFrequency = std::stod(value); }
            else if (key == "min-ins") { minInstructions = std::stoi(value); }
            else if (key == "max-ins") { maxInstructions = std::stoi(value); }
            else if (key == "delays-per-exec") { delaysPerExecution = std::stod(value); }
        }
        else 
            std::cerr << "Warning: Unrecognized parameter in config file: " << key << std::endl;
    }

    file.close();
}


int Scheduler::getBatchProcessFrequency() const{
    return batchProcessFrequency;
}

int Scheduler::getMinInstructions() const{
    return minInstructions;
}

int Scheduler::getMaxInstructions() const{
    return maxInstructions;
}

std::vector<std::shared_ptr<Process>> Scheduler::getRunningProcesses() const {
    std::lock_guard<std::mutex> lock(queueMutex);
    std::vector<std::shared_ptr<Process>> running;

    for (const auto& process : runningProcesses){
        if (process != nullptr && process->currentState == Process::RUNNING) {
            running.push_back(process);
        }
    }
    return running;
}

std::vector<std::shared_ptr<Process>> Scheduler::getFinishedProcesses() const {

    return finishedProcesses;
}

void Scheduler::shutdown(){
    running = false;
    processCV.notify_all(); // Notify all threads to wake up
    for (auto& thread : coreThreads){
        if (thread.joinable())
            thread.join();
    }
}
