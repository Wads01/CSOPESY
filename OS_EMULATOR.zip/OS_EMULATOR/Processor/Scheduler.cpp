#include "Scheduler.h"
#include <iostream>

Scheduler::Scheduler() : running(true){
    cores.resize(4);

    for (auto& core : cores)
        core.available = true;
}

Scheduler::~Scheduler(){
    running = false;
    for (auto& core : cores){
        if (core.thread.joinable())
            core.thread.join();
    }
}

void Scheduler::addProcess(std::shared_ptr<Process> process){
    std::lock_guard<std::mutex> lock(queueMutex);
    processQueue.push(process);
}

void Scheduler::run(){
    while (running){
        std::shared_ptr<Process> process;
        {
            std::lock_guard<std::mutex> lock(queueMutex);
            if (!processQueue.empty()) {
                process = processQueue.front();
                processQueue.pop();
            }
        }
        if (process){
            bool assigned = false;
            for (auto& core : cores){
                if (core.available){
                    core.available = false;
                    core.currentProcess = process;
                    core.currentProcess->currentState = Process::RUNNING;
                    core.thread = std::thread(&Scheduler::executeProcess, this, process);
                    assigned = true;
                    break;
                }
            }
            if (!assigned)
                process->currentState = Process::WAITING;
        }
        else
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void Scheduler::executeProcess(std::shared_ptr<Process> process){
    process->executeCurrentCommand();

    for (auto& core : cores){
        if (core.currentProcess == process){
            core.available = true;
            break;
        }
    }
}
