#include "Scheduler.h"
#include <iostream>
#include <chrono>
#include <thread>

Scheduler::Scheduler(int numCores) : numCores(numCores), running(true){
    runningProcesses.resize(numCores, nullptr);
}

Scheduler::~Scheduler(){
    shutdown();
}

Scheduler& Scheduler::getInstance(int numCores) {
    static Scheduler instance(numCores);
    return instance;
}

void Scheduler::addProcess(std::shared_ptr<Process> process){
    std::unique_lock<std::mutex> lock(queueMutex);

    // Add the process to queue
    readyQueue.push(process);
    process->currentState = Process::WAITING;
    processCV.notify_one();
}


void Scheduler::run(){
    while (running){
        std::unique_lock<std::mutex> lock(queueMutex);

        // Wait for processes
        processCV.wait(lock, [this] { return !readyQueue.empty() || !running; });

        // Assign processes to available cores
        for (int i = 0; i < numCores; ++i) {
            if (!runningProcesses[i] && !readyQueue.empty()){
                auto process = readyQueue.front();
                readyQueue.pop();
                runningProcesses[i] = process;
                process->currentState = Process::RUNNING;
                coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process, i));
            }
        }

        lock.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(100)); // Allow other threads to run
    }
}

void Scheduler::shutdown(){
    running = false;
    processCV.notify_all(); // Notify all threads to wake up
    for (auto& thread : coreThreads){
        if (thread.joinable())
            thread.join();
    }
}

void Scheduler::executeProcess(std::shared_ptr<Process> process, int coreID){
    process->cpuCoreID = coreID;
    process->homeworkProcess();

    {
        std::lock_guard<std::mutex> lock(process->mutex);
        process->currentState = Process::FINISHED;
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex);
        runningProcesses[coreID] = nullptr; // Free up core
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex);
        finishedProcesses.push_back(process);   // Put process to finished processes
    }
}

std::vector<std::shared_ptr<Process>> Scheduler::getRunningProcesses() const {
    std::lock_guard<std::mutex> lock(queueMutex);
    std::vector<std::shared_ptr<Process>> running;

    for (const auto& process : runningProcesses){
        if (process != nullptr && process->currentState == Process::RUNNING) {
            running.push_back(process);
        }
    }
    return running;
}

std::vector<std::shared_ptr<Process>> Scheduler::getFinishedProcesses() const {

    return finishedProcesses;
}
