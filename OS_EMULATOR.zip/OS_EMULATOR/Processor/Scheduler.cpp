#include "Scheduler.h"
#include <iostream>
#include <chrono>
#include <thread>

Scheduler::Scheduler(int numCores) : numCores(numCores), running(true){
    runningProcesses.resize(numCores, nullptr);
}

Scheduler::~Scheduler(){
    shutdown();
}

Scheduler& Scheduler::getInstance(int numCores) {
    static Scheduler instance(numCores);
    return instance;
}

void Scheduler::addProcess(std::shared_ptr<Process> process) {
    std::unique_lock<std::mutex> lock(queueMutex);

    // Find an available core
    for (int i = 0; i < numCores; ++i) {
        if (!runningProcesses[i]){
            runningProcesses[i] = process;
            process->currentState = Process::RUNNING;
            coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process, i));
            return;
        }
    }

    // If no core is available, add to ready queue
    readyQueue.push(process);
    process->currentState = Process::WAITING;
    processCV.notify_one();
}

void Scheduler::run(){
    while (running){
        std::unique_lock<std::mutex> lock(queueMutex);

        // Wait for processes
        processCV.wait(lock, [this] { return !readyQueue.empty() || !running; });

        // Assign processes to available cores
        for (int i = 0; i < numCores; ++i) {
            if (!runningProcesses[i] && !readyQueue.empty()){
                auto process = readyQueue.front();
                readyQueue.pop();
                runningProcesses[i] = process;
                process->currentState = Process::RUNNING;
                coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process, -1));
            }
        }

        lock.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(100)); // Allow other threads to run
    }
}

void Scheduler::shutdown(){
    running = false;
    processCV.notify_all(); // Notify all threads to wake up
    for (auto& thread : coreThreads){
        if (thread.joinable())
            thread.join();
    }
}

void Scheduler::executeProcess(std::shared_ptr<Process> process, int coreID){
    process->cpuCoreID = coreID;
    process->homeworkProcess();

    {
        std::lock_guard<std::mutex> lock(process->mutex);
        process->currentState = Process::FINISHED;
    }

    for (int i = 0; i < numCores; ++i){
        if (runningProcesses[i] == process){
            runningProcesses[i] = nullptr; // Free up core
            processFinished(i);
            break;
        }
    }
}

void Scheduler::processFinished(int coreID){

    // assign cores to ready queue
    if(!readyQueue.empty()){
        auto process = readyQueue.front();
        readyQueue.pop();
        runningProcesses[coreID] = process;
        process->currentState = Process::RUNNING;
        coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process, coreID));
    }
}
