#include "Scheduler.h"
#include <iostream>
#include <chrono>
#include <thread>

Scheduler::Scheduler(int numCores) : numCores(numCores), running(true) {
    runningProcesses.resize(numCores, nullptr);
}

Scheduler::~Scheduler() {
    shutdown();
}

void Scheduler::addProcess(std::shared_ptr<Process> process) {
    std::unique_lock<std::mutex> lock(queueMutex);

    for (int i = 0; i < numCores; ++i) {
        if (!runningProcesses[i]) {
            runningProcesses[i] = process;
            process->cpuCoreID = i;
            process->currentState = Process::RUNNING;
            coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process));
            return;
        }
    }

    readyQueue.push(process);
    process->currentState = Process::WAITING;
    processCV.notify_one();
}

void Scheduler::run() {
    while (running) {
        std::unique_lock<std::mutex> lock(queueMutex);
        processCV.wait(lock, [this] { return !readyQueue.empty() || !running; });

        for (int i = 0; i < numCores; ++i) {
            if (!runningProcesses[i] && !readyQueue.empty()) {
                auto process = readyQueue.front();
                readyQueue.pop();
                runningProcesses[i] = process;
                process->currentState = Process::RUNNING;
                coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process));
            }
        }

        lock.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

void Scheduler::shutdown() {
    running = false;
    processCV.notify_all();
    for (auto& thread : coreThreads) {
        if (thread.joinable())
            thread.join();
    }
}

void Scheduler::executeProcess(std::shared_ptr<Process> process) {
    process->homeworkProcess();

    {
        std::lock_guard<std::mutex> lock(process->mutex);
        process->currentState = Process::FINISHED;
    }

    {
        std::lock_guard<std::mutex> lock(queueMutex);
        for (int i = 0; i < numCores; ++i) {
            if (runningProcesses[i] == process) {
                runningProcesses[i] = nullptr;
                processFinished(i);
                break;
            }
        }
    }
}

void Scheduler::processFinished(int coreID) {
    std::lock_guard<std::mutex> lock(queueMutex);

    if (!readyQueue.empty()) {
        auto process = readyQueue.front();
        readyQueue.pop();
        runningProcesses[coreID] = process;
        process->currentState = Process::RUNNING;
        coreThreads.push_back(std::thread(&Scheduler::executeProcess, this, process));
    }
}
