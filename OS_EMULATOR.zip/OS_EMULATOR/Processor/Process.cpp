#include <iostream>
#include <fstream>
#include <string>

#include "Process.h"
#include "../Command/PrintCommand.h"
#include "../UI/UI_Manager.h"

Process::Process(int pid, const std::string &name, RequirementFlags requirementFlags, const std::string &timestamp)
    : pid(pid), name(name), commandCounter(0), cpuCoreID(-1), requirementFlags(requirementFlags), currentState(READY), timestamp(timestamp) {}

void Process::addCommand(ICommand::CommandType commandType){
    switch (commandType) {
        case ICommand::PRINT:
            commandList.push_back(std::make_shared<PrintCommand>(pid, "Hello WOrld"));
            break;
        // can add more
        default:
            break;
    }
}

void Process::executeCurrentCommand() const{
    if (commandCounter < static_cast<int>(commandList.size())){
        commandList[commandCounter]->execute();
    }
}

void Process::moveToNextLine(){
    if (commandCounter < static_cast<int>(commandList.size())){
        commandCounter++;
        if (commandCounter == static_cast<int>(commandList.size())){
            currentState = FINISHED;
        }
    }
}

int Process::getPID() const{
    return pid;
}

int Process::getCommandCounter() const{
    return commandCounter;
}

std::string Process::getName() const{
    return name;
}

std::string Process::getTimestamp() const{
    return timestamp;
}

int Process::getCpuCoreID() const{
    return cpuCoreID;
};

std::string Process::getCurrentState() const{
    return std::to_string(currentState);
};

void Process::homeworkProcess(){
    UI_Manager& ui = UI_Manager::getInstance();
    
    std::string filename = getName() + "_log.txt";
    std::ofstream logFile(filename);

    if (!logFile.is_open()) {
        std::cerr << "Failed to open log file: " << filename << std::endl;
        return;
    }

    logFile << "Process Name: " << getName() << "\n";
    logFile << "Logs:\n";

    for (int i = 0; i < 100; ++i) {
        // Get current timestamp for each log entry
        std::string timestamp = ui.generateTimestamp();

        logFile << "(" << timestamp << ") Core:" << std::to_string(cpuCoreID) 
                << " \"Hello World from " << getName() << "!\"\n";
    }

    logFile.close();
}