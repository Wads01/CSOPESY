#include <iostream>
#include <fstream>
#include <string>
#include <thread>
#include <chrono>
#include <random>

#include "Process.h"
#include "../Command/PrintCommand.h"
#include "../UI/UI_Manager.h"

Process::Process(int pid, const std::string &name, RequirementFlags requirementFlags, const std::string &timestamp, int minInstructions, int maxInstructions)
    : pid(pid), name(name), commandCounter(0), cpuCoreID(-1), requirementFlags(requirementFlags), currentState(READY), timestamp(timestamp), minInstructions(minInstructions), maxInstructions(maxInstructions) {}

void Process::addCommand(ICommand::CommandType commandType){
    switch (commandType) {
        case ICommand::PRINT:
            commandList.push_back(std::make_shared<PrintCommand>(pid, "Hello WOrld"));
            break;
        // can add more
        default:
            break;
    }
}

void Process::executeCurrentCommand() const{
    if (commandCounter < static_cast<int>(commandList.size())){
        commandList[commandCounter]->execute();
    }
}

void Process::moveToNextLine(){
    if (commandCounter < static_cast<int>(commandList.size())){
        commandCounter++;
        if (commandCounter == static_cast<int>(commandList.size())){
            currentState = FINISHED;
        }
    }
}

void Process::executeTask(){
    int numInstructions = generateRandomNumber(minInstructions, maxInstructions);

    this->maxInstructions = numInstructions - 1;

    for(int i = 0; i < numInstructions; i++){
        currInstruction = i;
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }

    this->currentState = Process::FINISHED;
}

int Process::generateRandomNumber(int min, int max){
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(min, max);

    return dis(gen);
}

int Process::getPID() const{
    return pid;
}

int Process::getCommandCounter() const{
    return commandCounter;
}

std::string Process::getName() const{
    return name;
}

std::string Process::getTimestamp() const{
    return timestamp;
}

int Process::getCpuCoreID() const{
    return cpuCoreID;
};

int Process::getMinInstructions() const{
    return minInstructions;
};

int Process::getMaxInstructions() const{
    return maxInstructions;
};

int Process::getCurrInstructions() const{
    return currInstruction;
};