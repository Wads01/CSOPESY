#pragma once
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include <vector>
#include "Process.h"

class Scheduler {
public:
    static Scheduler& getInstance(int numCores = 4);
    void addProcess(std::shared_ptr<Process> process);
    void run();
    void shutdown();

private:
    Scheduler(int numCores);
    ~Scheduler();
    Scheduler(const Scheduler&) = delete;
    Scheduler& operator=(const Scheduler&) = delete;

    void executeProcess(std::shared_ptr<Process> process);
    void processFinished(int coreID);

    std::queue<std::shared_ptr<Process>> readyQueue;
    std::vector<std::thread> coreThreads;
    std::vector<std::shared_ptr<Process>> runningProcesses;
    std::mutex queueMutex;
    std::mutex processMutex;
    int numCores;
    bool running;
};

#endif