#pragma once
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <fstream>
#include <sstream>
#include <stdexcept>
#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include <vector>
#include <condition_variable>

#include "Process.h"

class Scheduler{
public:
    static Scheduler& getInstance();
    static void initialize();
    static void destroy();
    void addProcess(std::shared_ptr<Process> process);
    void run();
    void shutdown();
    std::condition_variable processCV;

    int getBatchProcessFrequency() const;
    int getMinInstructions() const;
    int getMaxInstructions() const;
    std::vector<std::shared_ptr<Process>> getRunningProcesses() const;
    std::vector<std::shared_ptr<Process>> getFinishedProcesses() const;

    void getInfo();
    void readConfigFile(const std::string& filename);

private:
    Scheduler();
    ~Scheduler();
    Scheduler(const Scheduler&) = delete;
    Scheduler& operator=(const Scheduler&) = delete;

    std::string schedulerAlgorithm;
    int quantumCycles;
    double batchProcessFrequency;
    int minInstructions;
    int maxInstructions;
    double delaysPerExecution;

    void executeProcess(std::shared_ptr<Process> process, int coreID);
    void processFinished(int coreID);
    void roundRobin(int quantumCycles);

    std::queue<std::shared_ptr<Process>> readyQueue;
    std::vector<std::thread> coreThreads;
    std::vector<std::shared_ptr<Process>> runningProcesses;
    std::vector<std::shared_ptr<Process>> finishedProcesses;
    std::mutex processMutex;
    mutable std::mutex queueMutex;
    int numCores;
    bool running;
    bool createProcess;

    static Scheduler* sharedInstance;
};

#endif