#pragma once
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include "Process.h"

class Scheduler{
public:
    Scheduler();
    ~Scheduler();

    void addProcess(std::shared_ptr<Process> process);
    void run();

private:
    struct Core{
        std::thread thread;
        std::shared_ptr<Process> currentProcess;
        bool available;
    };

    std::queue<std::shared_ptr<Process>> processQueue;
    std::mutex queueMutex;
    bool running;
    std::vector<Core> cores;

    void executeProcess(std::shared_ptr<Process> process);
};

#endif
