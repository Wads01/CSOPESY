#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <memory>
#include "Process.h"

class Scheduler {
public:
    Scheduler(int numCores);
    ~Scheduler();

    void addProcess(std::shared_ptr<Process> process);
    void run();
    void shutdown();

private:
    int numCores;
    std::vector<std::shared_ptr<Process>> runningProcesses;
    std::queue<std::shared_ptr<Process>> readyQueue;
    std::vector<std::thread> coreThreads;
    std::mutex queueMutex;
    std::mutex processMutex;
    std::condition_variable processCV;
    bool running;

    void executeProcess(std::shared_ptr<Process> process);
    void processFinished(int coreID);
};

#endif
