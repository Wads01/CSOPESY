#pragma once
#ifndef PROCESS_H
#define PROCESS_H

#include <string>
#include <memory>
#include <vector>
#include <mutex>
#include <iostream>
#include <fstream>
#include <random>


#include "../Command/ICommand.h"

class Process{
public:
    struct RequirementFlags
    {
        bool requireFiles;
        int numFiles;
        bool requireMemory;
        int memoryRequired;
    };
    enum ProcessState
    {
        READY,
        RUNNING,
        WAITING,
        FINISHED
    };

    Process(int pid, const std::string &name, RequirementFlags requirementFlags, const std::string &timestamp, int minInstructions, int maxInstructions);
    void addCommand(ICommand::CommandType commandType);
    void executeCurrentCommand() const;
    void moveToNextLine();

    int getPID() const;
    int getCommandCounter() const;
    std::string getName() const;
    std::string getTimestamp() const;
    int getCpuCoreID() const;
    int getMinInstructions() const;
    int getMaxInstructions() const;
    int getCurrInstructions() const;

    void executeTask();
    int generateRandomNumber(int min, int max);


private:
    int pid;
    std::string name;
    typedef std::vector<std::shared_ptr<ICommand>> CommandList;
    CommandList commandList;

    std::mutex mutex;
    int commandCounter;
    int cpuCoreID = -1;
    RequirementFlags requirementFlags;
    ProcessState currentState;
    std::string timestamp;
    int minInstructions;
    int maxInstructions;
    int currInstruction;

    friend class ResourceEmulator;
    friend class Scheduler;
};

#endif